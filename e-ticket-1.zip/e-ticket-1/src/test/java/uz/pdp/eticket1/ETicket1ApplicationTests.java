package uz.pdp.eticket1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ETicket1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
