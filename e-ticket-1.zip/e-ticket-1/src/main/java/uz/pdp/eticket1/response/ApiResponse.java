package uz.pdp.eticket1.response;

public class ApiResponse {
    String message;
    int status;
    Object data;

    public ApiResponse(String message, int status) {
        this.message = message;
        this.status = status;
    }
}
