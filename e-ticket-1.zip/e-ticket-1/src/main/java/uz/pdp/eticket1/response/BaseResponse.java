package uz.pdp.eticket1.response;

public interface BaseResponse {
    ApiResponse SUCCESS = new ApiResponse("Success", 1);
    ApiResponse FAILURE = new ApiResponse("Not Success", -1);
}
