package uz.pdp.eticket1.model.train;

import org.bson.types.ObjectId;

import java.math.BigDecimal;
import java.util.List;

public class Car {
    String type;
    List<Seat> seats;
    BigDecimal additionalPrice;
    short availableSeats;
}
