package uz.pdp.eticket1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import uz.pdp.eticket1.database.StationDatabase;
import uz.pdp.eticket1.model.station.Station;
import uz.pdp.eticket1.response.ApiResponse;
import uz.pdp.eticket1.response.BaseResponse;

import java.util.List;

@RestController
@RequestMapping("/station")
public class StationController implements BaseResponse {

    private final StationDatabase stationDatabase;

    @Autowired
    public StationController(StationDatabase stationDatabase) {
        this.stationDatabase = stationDatabase;
    }

    @PostMapping("/add")
    public ApiResponse addStation(@RequestBody Station station) {
        int i = stationDatabase.add(station);
        return (i == 1) ? SUCCESS : FAILURE;
    }

    @GetMapping("/get")
    public List<String> getStations() {
        return stationDatabase.getListJson();
    }
}
