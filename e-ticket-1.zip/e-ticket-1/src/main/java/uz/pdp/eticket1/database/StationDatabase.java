package uz.pdp.eticket1.database;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import uz.pdp.eticket1.database.base.BaseDatabase;
import uz.pdp.eticket1.model.station.Station;

import java.util.ArrayList;
import java.util.List;

@Component
public class StationDatabase implements BaseDatabase<Station> {
    MongoCollection<Document> collection = database.getCollection("stations");

    @Override
    public int add(Station station) {
        Document stationByName = getDocument(station.getName());
        if (stationByName == null) {
            Document document = station.getDocument();
            collection.insertOne(document);
            return 1;
        }
        return -1;
    }

    @Override
    public Document getDocument(String name) {
        Bson bson = Filters.eq("name", name);
        return collection.find(bson).first();
    }

    @Override
    public List<Station> get() {
        List<Station> stations = new ArrayList<>();
        return stations;
    }

    public List<String> getListJson() {
        List<String> json = new ArrayList<>();
        for (Document document : collection.find()) {
            json.add(document.toJson());
        }
        return json;
    }
}
