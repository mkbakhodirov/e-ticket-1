package uz.pdp.eticket1.model.train;

import java.util.List;

public class Train {
    String number;
    String fromStation;
    String toStation;
    String type;
    List<Car> cars;
    List<TrainStation> stations;
}
