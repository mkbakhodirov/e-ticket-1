package uz.pdp.eticket1.model.train;

public class TrainStation {
    String stationName;
    double km;
}
