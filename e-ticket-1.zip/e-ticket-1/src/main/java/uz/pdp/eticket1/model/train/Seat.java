package uz.pdp.eticket1.model.train;

import uz.pdp.eticket1.model.user.Passenger;

import java.util.Date;

public class Seat {
    byte status;
    Date arrivalDate;
    Date departureDate;
    Passenger passenger;
}
