package uz.pdp.eticket1.database.base;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.util.List;

public interface BaseDatabase<T> {
    MongoClient mongoClient = new MongoClient();
    MongoDatabase database = mongoClient.getDatabase("testMongoDB");

    int add(T t);
    Document getDocument(String str);
    List<T> get();
}
