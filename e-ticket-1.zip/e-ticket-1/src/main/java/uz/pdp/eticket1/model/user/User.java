package uz.pdp.eticket1.model.user;

import uz.pdp.eticket1.model.Ticket;
import uz.pdp.eticket1.model.base.BaseModel;
import uz.pdp.eticket1.model.user.Passenger;

import java.util.List;

public class User extends BaseModel {
    String email;
    String phoneNumber;
    String password;
    List<Passenger> passengers;
    List<Ticket> tickets;
}
