package uz.pdp.eticket1.model.base;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Data
public abstract class BaseModel {
    ObjectId id;
    Date creationDate;

    {
        creationDate = new Date();
    }

}
