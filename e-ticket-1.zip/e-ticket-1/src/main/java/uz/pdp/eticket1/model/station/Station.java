package uz.pdp.eticket1.model.station;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.bson.Document;
import uz.pdp.eticket1.model.base.BaseModel;
import uz.pdp.eticket1.model.train.Train;

import java.util.Date;
import java.util.Map;

@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Station extends BaseModel {
    String name;
    String city;
    Map<Date, Train> trains;

    public Document getDocument() {
        return new Document("name", name).append("city", city)
                .append("trains", trains);
    }

    public Station(Document document) {
    }
}
