package uz.pdp.eticket1.model.user;

import uz.pdp.eticket1.model.base.BaseModel;

import java.time.LocalDate;

public class Passenger extends BaseModel {
    String passengerType;
    String firstName;
    String lastName;
    String patronymic;
    String gender;
    String documentType;
    String documentNumber;
    String country;
    LocalDate birthDate;
}
