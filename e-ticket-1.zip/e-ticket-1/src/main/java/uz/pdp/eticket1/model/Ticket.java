package uz.pdp.eticket1.model;

import uz.pdp.eticket1.model.base.BaseModel;
import uz.pdp.eticket1.model.user.Passenger;

import java.math.BigDecimal;
import java.util.Date;

public class Ticket extends BaseModel {
    Passenger passenger;
    String trainNumber;
    String trainType;
    String carNumber;
    String carType;
    String seat;
    String fromStation;
    String toStation;
    Date arrivalDate;
    Date departureDate;
    BigDecimal price;
}
